package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeSocialProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(CollegeSocialProject2Application.class, args);
	}

}
