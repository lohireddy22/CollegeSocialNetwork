package com.exception;


	
	public class AdminIdNotFoundException extends RuntimeException {
		
		public AdminIdNotFoundException(String msg) {
			super(msg); 
		}

	}



