package com.exception;


public class PlacementOfficerIdNotFoundException extends RuntimeException {
	
	public PlacementOfficerIdNotFoundException(String msg) {
		super(msg);
	}

}
