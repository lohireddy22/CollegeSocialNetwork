
package com.exception;



public class FacultyNotFoundException extends RuntimeException {
	
	public FacultyNotFoundException(String msg) {
		super(msg); 
	}

}



