package javax.validation;

public @interface Valid {

}
